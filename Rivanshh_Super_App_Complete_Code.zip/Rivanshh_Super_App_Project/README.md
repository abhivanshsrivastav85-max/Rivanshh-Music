# Rivanshh Super App — combined project bundle

## Files
- `index.html`: complete frontend (restored full page and wired to backend search/chat endpoints).
- `backend/AloneAPI.py`: the provided AloneAPI SDK.
- `backend/app.py`: FastAPI proxy for music/video search, details, lyrics, and study AI.
- `backend/.env.example`: template only; put real keys in your local `.env` or hosting secrets.
- `downloader_screen.dart` and `pubspec.yaml`: Flutter files supplied in the conversation; these are included but not rebuilt into an APK.

## Run locally
1. In `backend/`, install `requirements.txt`.
2. Set environment variables from `.env.example` (do not upload secrets).
3. Run `uvicorn app:app --host 0.0.0.0 --port 8000` from `backend/`.
4. Serve `index.html` on the same origin or set `window.RIVANSHH_API_BASE` before the main script to your deployed HTTPS backend URL.

## Important
- The provided AloneAPI service could not be live-verified in this environment; endpoints may be unavailable, require a valid key, or return a different response schema. The frontend falls back to official YouTube/YouTube Music search if results are not usable.
- Playback for search results opens official YouTube links; this bundle does not expose the API key or generate direct copyrighted-media download links in the browser.
- Firebase login still needs the correct project/provider/domain setup.
- UPI launches a payment app only; it does not verify payment or create a real wallet.
- Study AI needs a Gemini API key on the backend. Per-user saved AI history and live JoinUs messaging still need database/auth rules.
- GitHub Pages can host the static HTML, but it cannot run this Python backend. Deploy backend separately on a Python host and set allowed CORS origins.
- Owner asset filenames: `assets/owner/dp.jpg`, `photo-01.jpg` … `photo-05.jpg`; reels: `assets/reels/reel-01.mp4`, `reel-01-poster.jpg`, `reel-02.mp4`, `reel-02-poster.jpg`, `reel-03.mp4`, `reel-03-poster.jpg`.
