"""
AloneAPI.py — Complete Multi-Platform API Client SDK & Wrapper for AloneMusicAPI

License: GNU GPL v3.0

Provides drop-in integration and full API access for 28+ media & music platforms:
YouTube, Spotify, JioSaavn, Apple Music, Resso, SoundCloud, Instagram, TikTok,
Twitter/X, Facebook, Bilibili, Deezer, Gaana, Tidal, Dailymotion, Pinterest,
Reddit, Snapchat, Twitch, Kick, Terabox, Threads, Tumblr, MXPlayer, IMDb,
Bluesky, Mastodon, and LinkedIn.

Default Configuration via Environment Variables:
- API_URL: Base URL of the API (default: "https://api.riteshyt.in")
- API_KEY: User API key for authenticated operations
"""

import asyncio
import json
import os
import re
import urllib.parse
from typing import Any, Dict, List, Optional, Union

try:
    import httpx
except ImportError:
    httpx = None


API_URL = os.getenv("API_URL", "https://api.riteshyt.in").rstrip("/")
API_KEY = os.getenv("API_KEY", "")


def detect_platform(url: str) -> str:
    """
    Detects the platform of a given URL.
    Returns the lower-case name of the detected platform or 'unknown'.
    """
    if not url:
        return "unknown"
    u = url.lower()
    if "youtube.com" in u or "youtu.be" in u:
        return "youtube"
    elif "spotify.com" in u:
        return "spotify"
    elif "jiosaavn.com" in u or "saavn.com" in u:
        return "jiosaavn"
    elif "music.apple.com" in u or "itunes.apple.com" in u:
        return "applemusic"
    elif "resso.com" in u or "m.resso.com" in u:
        return "resso"
    elif "soundcloud.com" in u:
        return "soundcloud"
    elif "instagram.com" in u or "instagr.am" in u:
        return "instagram"
    elif "tiktok.com" in u:
        return "tiktok"
    elif "twitter.com" in u or "x.com" in u:
        return "twitter"
    elif "facebook.com" in u or "fb.watch" in u:
        return "facebook"
    elif "bilibili.com" in u or "b23.tv" in u:
        return "bilibili"
    elif "deezer.com" in u or "deezer.page.link" in u:
        return "deezer"
    elif "gaana.com" in u:
        return "gaana"
    elif "tidal.com" in u:
        return "tidal"
    elif "dailymotion.com" in u or "dai.ly" in u:
        return "dailymotion"
    elif "pinterest.com" in u or "pin.it" in u:
        return "pinterest"
    elif "reddit.com" in u or "redd.it" in u:
        return "reddit"
    elif "snapchat.com" in u:
        return "snapchat"
    elif "twitch.tv" in u:
        return "twitch"
    elif "kick.com" in u:
        return "kick"
    elif "terabox.com" in u or "teraboxapp.com" in u or "1024tera.com" in u:
        return "terabox"
    elif "threads.net" in u:
        return "threads"
    elif "tumblr.com" in u:
        return "tumblr"
    elif "mxplayer.in" in u:
        return "mxplayer"
    elif "imdb.com" in u:
        return "imdb"
    elif "bsky.app" in u:
        return "bluesky"
    elif "mastodon.social" in u or "mastodon" in u:
        return "mastodon"
    elif "linkedin.com" in u:
        return "linkedin"
    return "unknown"


class AloneAPI:
    """
    Main SDK Client class for AloneMusicAPI.
    Supports both async methods and synchronous fallback wrappers.
    """

    def __init__(self, api_url: Optional[str] = None, api_key: Optional[str] = None, timeout: float = 30.0):
        self.api_url = (api_url or os.getenv("API_URL") or "https://api.riteshyt.in").rstrip("/")
        self.api_key = api_key or os.getenv("API_KEY") or ""
        self.timeout = timeout
        self._client: Optional[Any] = None

    async def _get_client(self):
        return self._client

    async def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        cookies: Optional[Dict[str, str]] = None,
    ) -> Any:
        params = params or {}
        if self.api_key and "api_key" not in params:
            params["api_key"] = self.api_key

        url = f"{self.api_url}{endpoint}"

        if httpx:
            async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
                res = await client.request(
                    method=method.upper(),
                    url=url,
                    params=params,
                    json=json_data,
                    headers=headers,
                    cookies=cookies,
                )
                if res.headers.get("content-type", "").startswith("application/json"):
                    return res.json()
                return {"status_code": res.status_code, "text": res.text, "url": str(res.url)}
        else:
            # Fallback using standard urllib
            if params:
                query_str = urllib.parse.urlencode(params)
                url = f"{url}?{query_str}"
            req = urllib.parse.Request(url, method=method.upper())
            if json_data:
                req.add_header("Content-Type", "application/json")
                body = json.dumps(json_data).encode("utf-8")
                req.data = body
            if headers:
                for k, v in headers.items():
                    req.add_header(k, v)

            def _sync_fetch():
                import urllib.request

                with urllib.request.urlopen(req, timeout=self.timeout) as response:
                    content_type = response.headers.get("Content-Type", "")
                    data = response.read().decode("utf-8")
                    if "application/json" in content_type:
                        return json.loads(data)
                    return {"status_code": response.status, "text": data, "url": response.geturl()}

            return await asyncio.to_thread(_sync_fetch)

    # ------------------------------------------------------------------------
    # System & Health
    # ------------------------------------------------------------------------

    async def health(self) -> Dict[str, Any]:
        """Check API system health status."""
        return await self._request("GET", "/health")

    # ------------------------------------------------------------------------
    # Search & Metadata Endpoints
    # ------------------------------------------------------------------------

    async def search(self, query: str, limit: int = 1) -> Dict[str, Any]:
        """Search music and videos on YouTube / multi-platform."""
        return await self._request("GET", "/search", params={"q": query, "limit": limit})

    async def details(self, link_or_id: str) -> Dict[str, Any]:
        """Get detailed metadata for a song/video link or Video ID."""
        return await self._request("GET", "/details", params={"link": link_or_id})

    async def video_info(self, vidid_or_link: str) -> Dict[str, Any]:
        """Get video information and metadata."""
        return await self._request("GET", "/video_info", params={"vidid": vidid_or_link})

    async def playlist(self, url: str, limit: int = 100) -> Dict[str, Any]:
        """Extract playlist tracks and metadata."""
        return await self._request("GET", "/playlist", params={"url": url, "limit": limit})

    async def mix(self, vidid: Optional[str] = None, query: Optional[str] = None, limit: int = 15) -> Dict[str, Any]:
        """Get radio mix and recommended tracks based on track ID or query."""
        params: Dict[str, Any] = {"limit": limit}
        if vidid:
            params["vidid"] = vidid
        if query:
            params["query"] = query
        return await self._request("GET", "/api/mix", params=params)

    # ------------------------------------------------------------------------
    # Multi-Platform Extractor & Media Streaming
    # ------------------------------------------------------------------------

    async def extract_platform(self, url: str) -> Dict[str, Any]:
        """Extract multi-platform media details (Instagram, TikTok, Spotify, Twitter, etc.)."""
        return await self._request("GET", "/api/platform/extract", params={"url": url})

    def stream_platform_url(self, url: str, audio_url: Optional[str] = None) -> str:
        """Construct universal streaming endpoint URL for a media source."""
        params = {"url": url}
        if audio_url:
            params["audio_url"] = audio_url
        if self.api_key:
            params["api_key"] = self.api_key
        return f"{self.api_url}/api/platform/stream?{urllib.parse.urlencode(params)}"

    def get_stream_url(
        self,
        query_or_id: str,
        dl_type: str = "audio",
        ext: Optional[str] = None,
        force: bool = False,
    ) -> str:
        """Construct direct streaming / download URL for audio or video."""
        ext_val = ext or ("mp3" if dl_type == "audio" else "mp4")
        params = {"query": query_or_id, "dl_type": dl_type, "ext": ext_val}
        if force:
            params["force"] = "true"
        if self.api_key:
            params["api_key"] = self.api_key
        return f"{self.api_url}/download?{urllib.parse.urlencode(params)}"

    def musicbot_play_url(self, vidid: str) -> str:
        """Construct MusicBot audio stream redirect URL."""
        params = {}
        if self.api_key:
            params["api_key"] = self.api_key
        query = f"?{urllib.parse.urlencode(params)}" if params else ""
        return f"{self.api_url}/api/musicbot/play/{vidid}{query}"

    # ------------------------------------------------------------------------
    # Lyrics & User Features
    # ------------------------------------------------------------------------

    async def get_lyrics(self, query: Optional[str] = None, title: Optional[str] = None, artist: Optional[str] = None) -> Dict[str, Any]:
        """Fetch synchronized or plain lyrics using LRCLIB API integration."""
        params: Dict[str, Any] = {}
        if query:
            params["query"] = query
        if title:
            params["title"] = title
        if artist:
            params["artist"] = artist
        return await self._request("GET", "/api/lyrics", params=params)

    async def get_favorites(self, cookies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Fetch authenticated user's favorite tracks list."""
        return await self._request("GET", "/api/user/favorites", cookies=cookies)

    async def toggle_favorite(
        self,
        vidid: str,
        title: Optional[str] = None,
        artist: Optional[str] = None,
        thumbnail: Optional[str] = None,
        cookies: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Add or remove a track from user's favorites."""
        data = {"vidid": vidid, "title": title or "", "artist": artist or "", "thumbnail": thumbnail or ""}
        return await self._request("POST", "/api/user/favorites", json_data=data, cookies=cookies)

    async def get_playlists(self, cookies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Fetch user's custom playlists."""
        return await self._request("GET", "/api/user/playlists", cookies=cookies)

    async def create_playlist(self, name: str, cookies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Create a new user playlist."""
        return await self._request("POST", "/api/user/playlists", json_data={"name": name}, cookies=cookies)

    async def modify_playlist_track(
        self,
        playlist_id: str,
        action: str,
        track: Dict[str, Any],
        cookies: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Add or remove a track from a custom playlist."""
        data = {"playlist_id": playlist_id, "action": action, "track": track}
        return await self._request("POST", "/api/user/playlists/track", json_data=data, cookies=cookies)

    async def get_user_stats(self, cookies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Get user request statistics and play telemetry."""
        return await self._request("GET", "/api/user_stats", cookies=cookies)

    # ------------------------------------------------------------------------
    # API Key & Account Management
    # ------------------------------------------------------------------------

    async def generate_free_key(self, cookies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Generate or extend 30-day free API key."""
        return await self._request("POST", "/generate_free_key", cookies=cookies)

    async def remove_api_key(self, cookies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Revoke active API key."""
        return await self._request("POST", "/remove_api_key", cookies=cookies)

    # ------------------------------------------------------------------------
    # Authentication Endpoints
    # ------------------------------------------------------------------------

    async def auth_send_otp(self, email: str) -> Dict[str, Any]:
        """Send registration OTP to user's email."""
        return await self._request("POST", "/api/auth/send_otp", json_data={"email": email})

    async def auth_verify_otp(self, email: str, otp: str) -> Dict[str, Any]:
        """Verify registration OTP."""
        return await self._request("POST", "/api/auth/verify_otp", json_data={"email": email, "otp": otp})

    async def auth_register(self, name: str, email: str, password: str, otp: str) -> Dict[str, Any]:
        """Register new account."""
        return await self._request("POST", "/api/auth/register", json_data={"name": name, "email": email, "password": password, "otp": otp})

    async def auth_login(self, email: str, password: str) -> Dict[str, Any]:
        """Login with email and password."""
        return await self._request("POST", "/api/auth/login", json_data={"email": email, "password": password})

    async def auth_forgot_password_send_otp(self, email: str) -> Dict[str, Any]:
        """Send password reset OTP."""
        return await self._request("POST", "/api/auth/forgot_password/send_otp", json_data={"email": email})

    async def auth_forgot_password_verify_otp(self, email: str, otp: str) -> Dict[str, Any]:
        """Verify password reset OTP."""
        return await self._request("POST", "/api/auth/forgot_password/verify_otp", json_data={"email": email, "otp": otp})

    async def auth_forgot_password_reset(self, email: str, otp: str, new_password: str) -> Dict[str, Any]:
        """Reset password using verified OTP."""
        return await self._request(
            "POST", "/api/auth/forgot_password/reset", json_data={"email": email, "otp": otp, "new_password": new_password}
        )

    # ------------------------------------------------------------------------
    # Drop-in Helper Methods for Music Bots (Yukki, Yukon, Aviax, Fallen, Alone)
    # ------------------------------------------------------------------------

    async def valid(self, url: str) -> bool:
        """Check if a URL is valid across any of the supported 28+ platforms."""
        plat = detect_platform(url)
        return plat != "unknown"

    async def track(self, link_or_query: str) -> tuple[Dict[str, Any], str]:
        """
        Retrieves track details and video ID for music bots.
        Returns tuple of (details_dict, video_id).
        """
        res = await self.details(link_or_query)
        vidid = res.get("id") or res.get("vidid") or ""
        return res, vidid

    async def download_track(self, query_or_link: str, dl_type: str = "audio") -> str:
        """
        Returns direct stream or download URL for voice chat / music playback.
        """
        return self.get_stream_url(query_or_link, dl_type=dl_type)


# Direct synchronous instance helper for quick script usage
_default_client = AloneAPI()


def detect_platform_sync(url: str) -> str:
    return detect_platform(url)


if __name__ == "__main__":

    async def main():
        print("==================================================")
        print("   AloneAPI SDK Initialized successfully!         ")
        print(f"   API Base URL: {API_URL}                       ")
        print(f"   API Key: {'Set' if API_KEY else 'Not Set'}    ")
        print("==================================================")

        client = AloneAPI()

        # Test Health Check
        try:
            print("\n1. Testing Health Endpoint (/health)...")
            res = await client.health()
            print("Response:", res)
        except Exception as e:
            print("Health test exception:", e)

        # Test Search
        try:
            print("\n2. Testing Search Endpoint (/search)...")
            res = await client.search("Alone Alan Walker", limit=1)
            print("Search result title:", res.get("result", [{}])[0].get("title", "N/A"))
        except Exception as e:
            print("Search test exception:", e)

        # Test Stream URL Generation
        stream_url = client.get_stream_url("Alone Alan Walker", dl_type="audio")
        print("\n3. Stream URL:", stream_url)

        print("\nAll initialization checks completed!")

    asyncio.run(main())
