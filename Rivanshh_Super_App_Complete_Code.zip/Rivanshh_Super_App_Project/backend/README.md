# Backend setup

1. Install Python 3.10+ and run `pip install -r requirements.txt`.
2. Copy `.env.example` to `.env` and add your API keys locally. Do not commit `.env`.
3. Start from this folder: `uvicorn app:app --host 0.0.0.0 --port 8000`.
4. Check `http://127.0.0.1:8000/api/health`. A successful response depends on the provider being online and your key being valid.

For production, use HTTPS, authentication, a persistent distributed rate limiter, logging, and per-user authorization. The sample in-memory limiter is only a basic development guard. Never expose API keys in the browser.
