import os, time, re
from collections import defaultdict, deque
from typing import Any
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import httpx
from dotenv import load_dotenv
from AloneAPI import AloneAPI

load_dotenv()

app = FastAPI(title="Rivanshh Super App API", version="1.0.0")
origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["Content-Type", "Authorization"])
client = AloneAPI(api_url=os.getenv("API_URL", "https://api.riteshyt.in"), api_key=os.getenv("API_KEY", ""), timeout=float(os.getenv("API_TIMEOUT", "20")))
requests_by_ip = defaultdict(deque)
RATE_LIMIT = int(os.getenv("RATE_LIMIT_PER_MINUTE", "30"))

async def limit_requests(request: Request):
    ip = request.client.host if request.client else "unknown"
    now = time.time(); q = requests_by_ip[ip]
    while q and now - q[0] > 60: q.popleft()
    if len(q) >= RATE_LIMIT: raise HTTPException(status_code=429, detail="Rate limit exceeded; try again in a minute.")
    q.append(now)

def normalize_items(payload: Any):
    items=[]; seen=set()
    def walk(v, depth=0):
        if depth>4 or v is None: return
        if isinstance(v, list):
            for x in v: walk(x, depth+1)
            return
        if not isinstance(v, dict): return
        title = v.get("title") or v.get("name") or v.get("video_title") or v.get("track") or v.get("song")
        link = v.get("url") or v.get("link") or v.get("webpage_url") or v.get("watch_url") or ""
        raw_id = v.get("videoId") or v.get("video_id") or v.get("vidid") or v.get("id") or ""
        video_id = str(raw_id) if re.fullmatch(r"[\w-]{11}", str(raw_id or "")) else ""
        if not video_id and link:
            m = re.search(r"(?:[?&]v=|youtu\.be/|youtube\.com/(?:embed|shorts)/)([\w-]{11})", str(link))
            if m: video_id=m.group(1)
        if title and (video_id or link) and str(video_id or link) not in seen:
            seen.add(str(video_id or link))
            items.append({"title":str(title),"artist":str(v.get("artist") or v.get("channel") or v.get("channelTitle") or v.get("uploader") or "YouTube"),"video_id":video_id,"url":str(link),"thumbnail":str(v.get("thumbnail") or v.get("thumbnail_url") or v.get("cover") or v.get("image") or v.get("thumb") or "")})
        for k, val in v.items():
            if str(k).lower() in {"results","result","items","videos","tracks","data","music","songs"}: walk(val, depth+1)
    walk(payload)
    return items[:20]

@app.get("/api/health")
async def health(request: Request):
    await limit_requests(request)
    try: return {"ok": True, "provider": await client.health()}
    except Exception as exc: raise HTTPException(status_code=502, detail=f"Provider health check failed: {type(exc).__name__}")

@app.get("/api/music/search")
async def music_search(request: Request, q: str):
    await limit_requests(request)
    if not q.strip(): raise HTTPException(status_code=400, detail="q is required")
    try:
        data = await client.search(q.strip(), limit=12)
        return {"items": normalize_items(data), "provider_response": data}
    except Exception as exc: raise HTTPException(status_code=502, detail=f"Music provider request failed: {type(exc).__name__}")

@app.get("/api/tube/search")
async def tube_search(request: Request, q: str):
    await limit_requests(request)
    if not q.strip(): raise HTTPException(status_code=400, detail="q is required")
    try:
        data = await client.search(q.strip(), limit=12)
        return {"items": normalize_items(data), "provider_response": data}
    except Exception as exc: raise HTTPException(status_code=502, detail=f"Video provider request failed: {type(exc).__name__}")

@app.get("/api/music/details")
async def music_details(request: Request, link: str):
    await limit_requests(request)
    try: return await client.details(link)
    except Exception as exc: raise HTTPException(status_code=502, detail=f"Details request failed: {type(exc).__name__}")

@app.get("/api/music/lyrics")
async def music_lyrics(request: Request, query: str):
    await limit_requests(request)
    try: return await client.get_lyrics(query=query)
    except Exception as exc: raise HTTPException(status_code=502, detail=f"Lyrics request failed: {type(exc).__name__}")

class StudyMessage(BaseModel):
    message: str

@app.post("/api/study/chat")
async def study_chat(request: Request, body: StudyMessage):
    await limit_requests(request)
    key = os.getenv("GEMINI_API_KEY", "")
    if not key: raise HTTPException(status_code=503, detail="Study AI is not configured. Set GEMINI_API_KEY on the server.")
    message = body.message.strip()
    if not message: raise HTTPException(status_code=400, detail="message is required")
    prompt = "You are a Hindi/Hinglish study tutor for Physics, Chemistry, Mathematics and school/JEE study topics. Answer study-related questions clearly, step by step. If the request is unrelated to education, politely say this bot only helps with study content. User question: " + message
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
    try:
        async with httpx.AsyncClient(timeout=35) as session:
            resp = await session.post(url, json={"contents":[{"parts":[{"text":prompt}]}]})
            if resp.status_code >= 400: raise HTTPException(status_code=502, detail="Gemini provider request failed")
            data=resp.json()
        answer = "".join(p.get("text", "") for p in data.get("candidates", [{}])[0].get("content", {}).get("parts", []))
        if not answer: raise HTTPException(status_code=502, detail="AI returned an empty response")
        return {"answer":answer}
    except HTTPException: raise
    except Exception as exc: raise HTTPException(status_code=502, detail=f"Study AI request failed: {type(exc).__name__}")
